document.getElementById("loginForm").addEventListener("submit", async function(event) { 
    event.preventDefault();

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    console.log("Sending login attempt:", username, password); // Debugging

    const response = await fetch("/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({ username, password }) // Manually send data
    });

    const result = await response.json();

    if (result.success) {
        window.location.href = result.redirectUrl;
    } else {
        document.getElementById("message").innerText = result.message;
    }
});


