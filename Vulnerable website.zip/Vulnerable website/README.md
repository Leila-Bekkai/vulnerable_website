To get the correct username and password , you should enumerate a valid username, brute-force this user's password using the content of links below, then access their account page.
link: http://localhost:3000/
